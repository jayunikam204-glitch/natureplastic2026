document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("auth-form");
  const loginTab = document.getElementById("login-tab");
  const registerTab = document.getElementById("register-tab");
  const nameInput = document.getElementById("auth-name");
  const nameLabel = document.getElementById("name-label");
  const emailInput = document.getElementById("auth-email");
  const passwordInput = document.getElementById("auth-password");
  const heading = document.getElementById("auth-heading");
  const subtitle = document.getElementById("auth-subtitle");
  const submit = document.getElementById("auth-submit");
  const message = document.getElementById("auth-message");
  let mode = "login";

  function setMode(nextMode) {
    mode = nextMode;
    const registering = mode === "register";
    loginTab.classList.toggle("active", !registering);
    registerTab.classList.toggle("active", registering);
    nameInput.hidden = !registering;
    nameLabel.hidden = !registering;
    nameInput.required = registering;
    passwordInput.autocomplete = registering ? "new-password" : "current-password";
    heading.textContent = registering ? "Create your account" : "Welcome back";
    subtitle.textContent = registering ? "Join EcoCare and save your quiz progress." : "Sign in to continue to your EcoCare quiz.";
    submit.textContent = registering ? "Create account" : "Login";
    message.textContent = "";
  }
  loginTab.addEventListener("click", () => setMode("login"));
  registerTab.addEventListener("click", () => setMode("register"));

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    submit.disabled = true;
    submit.textContent = mode === "register" ? "Creating account…" : "Signing in…";
    message.style.color = "";
    message.textContent = "";
    try {
      const response = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({
          name: nameInput.value.trim(),
          email: emailInput.value.trim(),
          password: passwordInput.value
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not sign in.");
      message.style.color = "#267a4b";
      message.textContent = "Success! Opening EcoCare…";
      window.location.href = "Index.html";
    } catch (error) {
      message.textContent = error.message || "Something went wrong. Please try again.";
    } finally {
      submit.disabled = false;
      submit.textContent = mode === "register" ? "Create account" : "Login";
    }
  });
});
