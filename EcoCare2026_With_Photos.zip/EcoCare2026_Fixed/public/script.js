document.addEventListener("DOMContentLoaded", () => {
  const $ = (id) => document.getElementById(id);
  const questionEl = $("question"), optionsEl = $("options"), feedbackEl = $("feedback");
  const scoreEl = $("score"), nextBtn = $("next-btn"), restartBtn = $("restart-btn");
  const nameInput = $("player-name"), resultsList = $("results-list"), resultsEmpty = $("results-empty");
  const progressLabel = $("quiz-progress"), progressFill = $("progress-fill"), statusEl = $("quiz-status");
  if (!questionEl || !optionsEl || !feedbackEl || !scoreEl || !nextBtn || !restartBtn) return;

  let questions = [], current = 0, score = 0, answered = false, attemptId = null, loggedIn = false;

  async function api(url, options = {}) {
    const response = await fetch(url, { credentials: "same-origin", ...options,
      headers: { ...(options.headers || {}) } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      if (response.status === 401) loggedIn = false;
      throw new Error(data.error || `Request failed (${response.status}).`);
    }
    return data;
  }

  async function checkSession() {
    try {
      const data = await api("/api/auth/me");
      loggedIn = Boolean(data.user);
      if (loggedIn) {
        if (nameInput && !nameInput.value) nameInput.value = data.user.name || "";
        const link = $("account-link");
        if (link) { link.textContent = "Logout"; link.href = "#logout"; }
        statusEl.textContent = `Signed in as ${data.user.name}. Your quiz answers are saved.`;
      }
    } catch (_) { loggedIn = false; }
    if (!loggedIn) {
      statusEl.innerHTML = 'Please <a href="login.html" style="color:#286b4c;font-weight:700">log in or create an account</a> before starting the quiz.';
    }
  }

  async function loadQuestions() {
    const data = await api("/api/questions");
    questions = Array.isArray(data.questions) ? data.questions : [];
    if (questions.length !== 10) throw new Error(`Expected 10 questions but received ${questions.length}. Check questions.json and restart the server.`);
  }

  async function loadResults() {
    if (!resultsList || !resultsEmpty || !loggedIn) return;
    try {
      const data = await api("/api/quiz/attempts");
      resultsList.replaceChildren();
      const attempts = data.attempts || [];
      resultsEmpty.hidden = attempts.length > 0;
      attempts.forEach((attempt) => {
        const li = document.createElement("li");
        li.textContent = `${attempt.name} — ${attempt.score} / ${attempt.total} (${attempt.completed ? "completed" : "in progress"})`;
        resultsList.appendChild(li);
      });
    } catch (_) {}
  }

  function updateProgress() {
    if (progressLabel) progressLabel.textContent = `Question ${Math.min(current + 1, questions.length)} of ${questions.length}`;
    if (progressFill) progressFill.style.width = `${(current / questions.length) * 100}%`;
    scoreEl.textContent = `Score: ${score} / ${questions.length}`;
  }

  function showQuestion() {
    answered = false;
    const item = questions[current];
    if (!item) return;
    questionEl.textContent = item.q || item.prompt || `Question ${current + 1}`;
    optionsEl.replaceChildren();
    feedbackEl.textContent = "";
    feedbackEl.className = "feedback";
    nextBtn.hidden = true;
    restartBtn.hidden = true;
    item.options.forEach((option, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "quiz-option";
      button.textContent = option;
      button.addEventListener("click", () => chooseAnswer(button, index, item));
      optionsEl.appendChild(button);
    });
    updateProgress();
  }

  async function chooseAnswer(selectedButton, selectedIndex, item) {
    if (answered) return;
    if (!loggedIn) {
      feedbackEl.textContent = "Please log in first to answer and save your result.";
      feedbackEl.className = "feedback bad";
      return;
    }
    answered = true;
    const buttons = [...optionsEl.querySelectorAll("button")];
    buttons.forEach((button) => button.disabled = true);
    try {
      if (!attemptId) {
        const started = await api("/api/quiz/start", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: nameInput?.value.trim() || "Guest" })
        });
        attemptId = started.attemptId;
      }
      const result = await api("/api/quiz/answer", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ attemptId, questionId: item.id, selectedIndex })
      });
      score = result.score;
      if (result.correct) {
        selectedButton.classList.add("correct");
        feedbackEl.textContent = "Correct! Well done — your answer is saved.";
        feedbackEl.className = "feedback good";
      } else {
        selectedButton.classList.add("incorrect");
        if (buttons[result.correctIndex]) buttons[result.correctIndex].classList.add("correct");
        feedbackEl.textContent = `Not quite. Correct answer: ${result.correctText}. Your answer is saved.`;
        feedbackEl.className = "feedback bad";
      }
      updateProgress();
      if (current < questions.length - 1) {
        nextBtn.hidden = false;
      } else {
        questionEl.textContent = "Quiz completed! 🌍";
        if (progressFill) progressFill.style.width = "100%";
        progressLabel.textContent = "All 10 questions completed";
        feedbackEl.textContent += ` Final score: ${score} out of ${questions.length}.`;
        restartBtn.hidden = false;
      }
      await loadResults();
    } catch (error) {
      answered = false;
      buttons.forEach((button) => button.disabled = false);
      feedbackEl.textContent = error.message;
      feedbackEl.className = "feedback bad";
      if (!loggedIn) feedbackEl.innerHTML = 'Your session may have expired. <a href="login.html">Log in again</a>.';
    }
  }

  async function beginQuiz() {
    current = 0; score = 0; attemptId = null;
    questionEl.textContent = "Loading questions…";
    optionsEl.replaceChildren();
    feedbackEl.textContent = "";
    nextBtn.hidden = true; restartBtn.hidden = true;
    try {
      await checkSession();
      await loadQuestions();
      showQuestion();
      await loadResults();
    } catch (error) {
      questionEl.textContent = "Quiz could not load";
      feedbackEl.textContent = `${error.message} Make sure you opened the site using http://localhost:3000 and started the server with npm start.`;
      feedbackEl.className = "feedback bad";
    }
  }

  nextBtn.addEventListener("click", () => {
    if (!answered || current >= questions.length - 1) return;
    current++;
    showQuestion();
  });
  restartBtn.addEventListener("click", beginQuiz);

  const accountLink = $("account-link");
  if (accountLink) accountLink.addEventListener("click", async (event) => {
    if (accountLink.href.endsWith("#logout")) {
      event.preventDefault();
      try { await api("/api/auth/logout", { method: "POST" }); } catch (_) {}
      window.location.href = "login.html";
    }
  });

  beginQuiz();
});
